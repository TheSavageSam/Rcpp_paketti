
// cppSample.h
std::vector<double> cppSample(int n, std::vector<double> values, std::vector<double> probabilities);
