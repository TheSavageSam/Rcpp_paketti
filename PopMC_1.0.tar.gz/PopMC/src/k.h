
double expit(double x);
std::vector<int> k(std::vector<int> smokes_hav, std::vector<double> age, std::vector<int> ymis_index, std::vector<double> theta);
