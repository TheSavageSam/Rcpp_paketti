
// rinitials.h
double rinitials(double a, double b);
